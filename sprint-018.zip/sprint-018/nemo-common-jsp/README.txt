Nemo: Novacroft common JSP library
