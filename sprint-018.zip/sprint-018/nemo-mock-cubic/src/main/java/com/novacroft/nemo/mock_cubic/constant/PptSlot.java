package com.novacroft.nemo.mock_cubic.constant;

public enum PptSlot {
    ONE, TWO, THREE, NOT_FOUND;
}
