package com.novacroft.nemo.mock_single_sign_on.constant;

public final class PageUrl {
    public static final String URL_SUFFIX = ".htm";
    
    public static final String MOCK_LOGOUT = Page.MOCK_LOGOUT + URL_SUFFIX;
    
    private PageUrl() {}
}
