Nemo: Novacroft common library
