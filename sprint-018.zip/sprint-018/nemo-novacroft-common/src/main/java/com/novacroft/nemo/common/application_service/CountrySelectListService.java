package com.novacroft.nemo.common.application_service;

import com.novacroft.nemo.common.transfer.SelectListDTO;

/**
 * ISO Country select list service
 */
public interface CountrySelectListService {
    SelectListDTO getSelectList();
}
