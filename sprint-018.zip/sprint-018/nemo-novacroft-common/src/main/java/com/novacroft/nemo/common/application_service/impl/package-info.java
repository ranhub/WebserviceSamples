package com.novacroft.nemo.common.application_service.impl;
/**
 * Novacroft common application service implementations.  Available for use by all applications.
 */
