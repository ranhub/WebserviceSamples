package com.novacroft.nemo.common.application_service;
/**
 * Novacroft common application services.  Available for use by all applications.
 */
