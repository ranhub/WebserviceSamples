package com.novacroft.nemo.common.command;

public interface CommonCallCmd {

    Long getCallTypeId();

    String getDescription();

    String getResolution();

    String getNotes();

}
