package com.novacroft.nemo.common.command;

/**
 * Current password command class common specification
 */
public interface CommonCurrentPasswordCmd {
    String getCurrentPassword();
}
