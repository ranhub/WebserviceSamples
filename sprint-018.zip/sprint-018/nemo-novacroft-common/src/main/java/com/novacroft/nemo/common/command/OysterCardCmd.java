package com.novacroft.nemo.common.command;

/**
 * Oyster Card command interface TfL definition
 */
public interface OysterCardCmd {
    String getCardNumber();
}
