package com.novacroft.nemo.common.constant;

/**
 * Common Freemarker template names
 */
public abstract class CommonFreemarkerTemplate {
    public static final String STANDARD_EMAIL_BODY = "emailBody.ftl";
}
