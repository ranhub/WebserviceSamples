package com.novacroft.nemo.common.constant;

/**
 * Common model attribute constants
 */
public abstract class CommonPageAttribute {
    public static final String PAGE_NAME = "pageName";
}
