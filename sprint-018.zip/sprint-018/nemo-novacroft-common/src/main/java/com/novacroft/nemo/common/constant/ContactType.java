package com.novacroft.nemo.common.constant;


/**
 * Values for contact type
 *
 * @see CommonContact
 */
public enum ContactType {
    HomePhone,
    MobilePhone;
}
