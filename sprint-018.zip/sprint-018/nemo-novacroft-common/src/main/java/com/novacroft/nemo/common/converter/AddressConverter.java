package com.novacroft.nemo.common.converter;

public interface AddressConverter {

}
