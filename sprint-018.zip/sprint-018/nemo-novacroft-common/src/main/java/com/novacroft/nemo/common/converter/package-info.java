package com.novacroft.nemo.common.converter;
/**
 * Novacroft common converter specifications.  Available for use by all applications.
 */
