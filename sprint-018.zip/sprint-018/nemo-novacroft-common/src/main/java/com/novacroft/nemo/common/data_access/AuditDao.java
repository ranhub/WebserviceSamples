package com.novacroft.nemo.common.data_access;

public class AuditDao {

}
