package com.novacroft.nemo.common.data_access;

import com.novacroft.nemo.common.domain.Call;
import org.springframework.stereotype.Repository;

@Repository("callDAO")
public class CallDAO extends BaseDAOImpl<Call> {

}
