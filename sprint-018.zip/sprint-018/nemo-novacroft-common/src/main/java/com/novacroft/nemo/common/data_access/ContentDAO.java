package com.novacroft.nemo.common.data_access;

import com.novacroft.nemo.common.domain.Content;

/**
 * Content data access implementation.
 */
public class ContentDAO extends BaseDAOImpl<Content> {
}
