package com.novacroft.nemo.common.data_access;
/**
 * Novacroft common data access classes (DAO).  Available for use by all applications.
 */
