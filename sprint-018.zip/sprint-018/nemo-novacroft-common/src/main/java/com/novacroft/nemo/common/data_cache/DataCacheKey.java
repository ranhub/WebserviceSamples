package com.novacroft.nemo.common.data_cache;

/**
 * Generic data cache key specification
 */
public interface DataCacheKey {
}
