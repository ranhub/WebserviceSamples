package com.novacroft.nemo.common.data_cache;

/**
 * Generic data cache value specification
 */
public interface DataCacheValue {
}
