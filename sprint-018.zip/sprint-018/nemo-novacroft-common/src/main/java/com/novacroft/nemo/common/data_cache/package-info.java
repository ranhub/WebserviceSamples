package com.novacroft.nemo.common.data_cache;
/**
 * Specifications of for caching data.
 */
