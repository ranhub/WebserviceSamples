package com.novacroft.nemo.common.data_service.impl;
/**
 * Novacroft common data service implementations.  Available for use by all applications.
 */
