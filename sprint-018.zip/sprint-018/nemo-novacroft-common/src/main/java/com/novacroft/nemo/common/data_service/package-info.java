package com.novacroft.nemo.common.data_service;
/**
 * Novacroft common data services.  Available for use by all applications.
 */
