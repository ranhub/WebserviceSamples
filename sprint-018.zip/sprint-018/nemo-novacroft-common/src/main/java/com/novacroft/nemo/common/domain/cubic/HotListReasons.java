package com.novacroft.nemo.common.domain.cubic;

import java.util.List;


/**
 * Hot list reasons
 */
public class HotListReasons {
    protected List<Integer> hotListReasonCodes;

    public List<Integer> getHotListReasonCodes() {
        return hotListReasonCodes;
    }

    public void setHotListReasonCodes(List<Integer> hotListReasonCodes) {
        this.hotListReasonCodes = hotListReasonCodes;
    }

}
