package com.novacroft.nemo.common.domain.cubic;

public interface PrePay {
	
	Integer getPickupLocation();

}
